// 入口文件，在项目中，就像一个清单一样


// 引入核心组件
import "./pages/App"
// import "./test/tetstBtn"   //test

// 引入初始化样式
import "normalize.css"

// 引入全局样式
import "./assets/styles/core.less"

//各种引入
//ant mobile样式引入
import 'antd-mobile/dist/antd-mobile.css'; // 导入样式文件





