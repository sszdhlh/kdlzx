import React from "react"
import ReactDOM from 'react-dom'
import {Button} from 'antd-mobile'



ReactDOM.render(<Button type="primary">Button Test</Button>, document.getElementById('root')); 